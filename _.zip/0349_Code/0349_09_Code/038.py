def count_tokens(raw, query):
    result = 0
    try:
