@ajax_login_required
def ajax_delete(request):
