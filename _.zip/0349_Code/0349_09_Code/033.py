    directory.functions.log_message(u'Deleted: ' + request.POST[u'id'] +
      u' by ' + request.user.username + u'.')
