    return HttpResponse(u'')
