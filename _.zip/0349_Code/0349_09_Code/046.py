    candidates.sort(lambda a, b: -cmp(a[1], b[1]))
