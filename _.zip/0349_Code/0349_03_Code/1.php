"INSERT INTO comments_log (comment, timestamp) VALUES ('" . $_POST['comment'] .  "', NOW());"
