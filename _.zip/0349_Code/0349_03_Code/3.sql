INSERT INTO comments_log (comment, timestamp) VALUES ('', NOW()); DELETE FROM comments_log; --', NOW());
