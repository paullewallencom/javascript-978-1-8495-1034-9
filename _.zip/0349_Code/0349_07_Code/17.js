$(function()
    {
    $(".autocomplete").combobox();
    $(".autocomplete").toggle();
