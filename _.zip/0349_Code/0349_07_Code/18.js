    /*
    $(".autocomplete").autocomplete({select: update_autocomplete});
    $(".autocomplete").bind({"autocompleteselect": update_autocomplete});
    $(".autocomplete").bind({"autocompletechange": update_autocomplete});
    */
    });
