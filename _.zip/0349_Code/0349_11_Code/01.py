name = models.TextField(blank = True, default = u'(Insert name here)')
