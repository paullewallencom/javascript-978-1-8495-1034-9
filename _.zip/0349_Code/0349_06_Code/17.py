# Relative pathname for user changes logfile for directory
LOGFILE = u'log'
