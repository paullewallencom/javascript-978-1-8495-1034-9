    (ur'^ajax/save', views.save),
    (ur'^profile/(\d+)$', views.profile),
