    (ur'^create/Entity', views.modelform_Entity),
    (ur'^create/Location', views.modelform_Location),
