    (r'^time$', 'sample.clock_skew.home'),
    (r'^time/json$', 'sample.clock_skew.timestamp'),
