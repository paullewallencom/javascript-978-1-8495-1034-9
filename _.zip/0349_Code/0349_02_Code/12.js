$.ajaxSetup({dataType: "text"});
