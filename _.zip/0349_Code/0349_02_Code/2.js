$("#result").load("/project/server.cgi", "text=world"); 
