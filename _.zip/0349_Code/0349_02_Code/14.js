$.ajax({success: function(data, textStatus, XMLHttpRequest) {
        processData(data);
        }, …
    });
