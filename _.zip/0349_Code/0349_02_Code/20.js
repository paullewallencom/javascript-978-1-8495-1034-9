$("form p:has(input[type=checkbox]:not(:checked))").load("/updates");
