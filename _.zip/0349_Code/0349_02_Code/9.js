customer.prototype = employee;
