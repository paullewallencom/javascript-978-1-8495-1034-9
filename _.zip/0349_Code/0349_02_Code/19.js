$("form p:has(input[type=checkbox]:not(:checked))").addClass("strikethru").delay(500).hide("slow");
