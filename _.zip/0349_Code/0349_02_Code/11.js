{page: 2, query: "pizza"}
