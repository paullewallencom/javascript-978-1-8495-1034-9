$("#result");
$("p");
$("p.summary");
$("a");
$("p a");
$("p > a");
$("li > p");
$("p.summary > a");
$("table.striped tr:even");
