$.ajax({error: function(XMLHttpRequest, textStatus, errorThrown)
        {
        registerError(textStatus);
        }, …
    });
