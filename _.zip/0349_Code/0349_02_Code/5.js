$("table.striped tr:even").addClass("even").hide("slow").delay(1000).show("slow");
