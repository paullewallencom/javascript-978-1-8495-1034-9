$.ajaxSetup({dataType: "text", type: "POST"});
