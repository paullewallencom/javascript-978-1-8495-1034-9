$("table.striped tr:even").addClass("even");
