Entity.objects.get(name__icontains = u'ed')
