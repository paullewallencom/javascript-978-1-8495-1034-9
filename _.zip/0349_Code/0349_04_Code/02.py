class ExtensionField(models.TextField):
    pass
