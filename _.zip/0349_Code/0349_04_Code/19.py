for entity in queryset.all():
    # Do something with each entity
