XMLHttpRequest.abort()
