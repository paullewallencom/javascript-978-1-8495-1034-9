django-admin.py startproject sample
