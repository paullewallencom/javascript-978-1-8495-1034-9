XMLHttpRequest.send(content)
