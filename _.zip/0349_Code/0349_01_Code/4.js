XMLHttpRequest.open(method, URL)
XMLHttpRequest.open(method, URL, asynchronous)
XMLHttpRequest.open(method, URL, asynchronous, username)
XMLHttpRequest.open(method, URL, asynchronous, username, password)
