MEDIA_ROOT = os.path.join(DIRNAME, 'static/')
