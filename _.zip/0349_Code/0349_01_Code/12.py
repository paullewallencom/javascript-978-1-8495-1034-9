    (r'^$', 'sample.views.home'),
