    (ur'^ajax/create_user', directory.views.create_user),
