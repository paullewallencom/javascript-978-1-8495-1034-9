@directory.functions.ajax_permission_required("Entity.delete")
def ajax_delete(request, id):
