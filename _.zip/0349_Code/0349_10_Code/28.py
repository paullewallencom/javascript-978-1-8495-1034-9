@login_required
@permission_required("Entity.view_changelog")
def changelog(request):
    ...
