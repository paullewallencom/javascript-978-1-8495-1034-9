class Increment(models.Model):
    pass
